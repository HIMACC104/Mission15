#!/bin/bash
docker run -p 80:5000 --name flask-web -d 129729052534.dkr.ecr.ap-northeast-1.amazonaws.com/cc104-web-student18:latest
